#include <stdio.h>

int main(void) {
    printf("Hello CS137 2030 Cohort! \n");
    return 0;
}
