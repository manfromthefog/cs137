int isSophieGermainPrime(int p);
int base2nat(int bs, int num);
int nat2base(int bs, int num);